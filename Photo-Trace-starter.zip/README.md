# Photo Trace

Starter Android project that wraps the Photo Trace web interface in an Android WebView.

## Build APK with GitHub Actions
1. Upload/extract these files into the root of a GitHub repository.
2. Ensure `.github/workflows/build.yml` is committed on the default branch.
3. Open **Actions** and run **Build APK**.
4. Download the `Photo-Trace-debug-apk` artifact from the completed run.

This starter builds a debug APK. It currently reports basic file details; it does not yet parse EXIF GPS or original capture timestamps.
